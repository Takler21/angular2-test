export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCAgwI9lSNwjZsPCEvJuc6qVxiw-moYEmA",
    authDomain: "fir-demo-1a77f.firebaseapp.com",
    databaseURL: "https://fir-demo-1a77f.firebaseio.com",
    projectId: "fir-demo-1a77f",
    storageBucket: "fir-demo-1a77f.appspot.com",
    messagingSenderId: "337223888744"
  }
};
